<?php
/**
 * Plugin Name:       Coco Form
 * Description:       A lightweight and customizable WordPress plugin for creating and managing dynamic forms with enhanced spam protection, email templates, and flexible styling options.
 * Version:           1.0.2
 * Author:            Adi Kica
 * Text Domain:       coco-form
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;
// Include the helper class first to have access to activation/deactivation methods.
require_once plugin_dir_path( __FILE__ ) . 'includes/class-coco-form-helper.php';

// Register activation and deactivation hooks.
register_activation_hook( __FILE__, [ 'Coco_Form_Helper', 'activate' ] );
register_deactivation_hook( __FILE__, [ 'Coco_Form_Helper', 'deactivate' ] );

// Include the main plugin class.
require_once plugin_dir_path( __FILE__ ) . 'includes/class-coco-form.php';

// Initialize the plugin.
function run_coco_form() {
    $plugin = new Coco_Form();
    $plugin->run();
}
run_coco_form();
