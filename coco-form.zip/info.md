##### add before closing /head tag

<?php
 $recaptcha_site_key = get_option('coco_form_recaptcha_site_key');          
if ($recaptcha_site_key) {echo '<script src="https://www.google.com/recaptcha/api.js?render=' . esc_attr($recaptcha_site_key) . '"></script>';}
?>

### add to footer 
<?php $rc_site_key = get_option('coco_form_recaptcha_site_key');?>
<script>
const site_key =<?php echo json_encode($rc_site_key) ?>;
if(site_key){
 grecaptcha.ready(function() {
      grecaptcha.execute(site_key, {action: 'contact'}).then(function(token) {
         document.querySelectorAll(".recaptchaResponse").forEach(elem => (elem.value = token));
      });
  });
}
</script>
