// assets/js/public-script.js

document.addEventListener('DOMContentLoaded', function() {
    // Ensure coco_forms_settings is available
    if (typeof coco_forms_settings === 'undefined') {
        console.error('coco_forms_settings is not defined.');
        return;
    }

    // Initialize forms
    for (var formId in coco_forms_settings) {
        if (coco_forms_settings.hasOwnProperty(formId)) {
            cocoFormInit(formId);
        }
    }

    // Function to initialize each form
    function cocoFormInit(formId) {
        var settings = coco_forms_settings[formId];
        var isPopup = parseInt(settings.is_popup);
        var delayTime = parseInt(settings.delay_time) || 0;
        var frequency = settings.frequency;
        var displayDevice = settings.display_device;
        var formSelector = '#coco-form-' + formId;
        var startTimeKey = 'coco_form_start_time_' + formId;

        // Frequency control using localStorage
        var showForm = true;
        var frequencyKey = 'coco_form_frequency_' + formId;

        if (frequency !== 'default') {
            var lastShown = localStorage.getItem(frequencyKey);
            if (lastShown) {
                var daysSinceLastShown = (Date.now() - parseInt(lastShown)) / (1000 * 60 * 60 * 24);
                if (daysSinceLastShown < parseInt(frequency)) {
                    showForm = false;
                }
            }
        }

        if (showForm) {
            if (isPopup) {
                // Display popup form after delay
                setTimeout(function() {
                    var overlay = document.getElementById('coco-form-popup-overlay-' + formId);
                    var container = document.getElementById('coco-form-popup-container-' + formId);

                    if (overlay && container) {
                        overlay.style.display = 'block';
                        container.style.display = 'block';
                    } else {
                        console.error('Popup elements not found for form ID:', formId);
                    }
                }, delayTime);

                // Close button functionality
                var closeButton = document.querySelector('#coco-form-popup-container-' + formId + ' .coco-form-close');
                if (closeButton) {
                    closeButton.addEventListener('click', function() {
                        document.getElementById('coco-form-popup-overlay-' + formId).style.display = 'none';
                        document.getElementById('coco-form-popup-container-' + formId).style.display = 'none';
                    });
                }

                // Close popup when clicking outside the form
                var overlay = document.getElementById('coco-form-popup-overlay-' + formId);
                if (overlay) {
                    overlay.addEventListener('click', function() {
                        overlay.style.display = 'none';
                        document.getElementById('coco-form-popup-container-' + formId).style.display = 'none';
                    });
                }
            } else {
                // Display inline form after delay
                setTimeout(function() {
                    var container = document.getElementById('coco-form-container-' + formId);
                    if (container) {
                        container.style.display = 'block';
                    } else {
                        console.error('Inline form container not found for form ID:', formId);
                    }
                }, delayTime);
            }

            // Set the last shown time
            if (frequency !== 'default') {
                localStorage.setItem(frequencyKey, Date.now());
            }
        } else {
            // Hide the form if frequency limit not met
            if (isPopup) {
                var overlay = document.getElementById('coco-form-popup-overlay-' + formId);
                var container = document.getElementById('coco-form-popup-container-' + formId);
                if (overlay && container) {
                    overlay.style.display = 'none';
                    container.style.display = 'none';
                }
            } else {
                var container = document.getElementById('coco-form-container-' + formId);
                if (container) {
                    container.style.display = 'none';
                }
            }
        }

        // Start time recording for spam protection
        window[startTimeKey] = Date.now();

        // Handle form submission
        var form = document.querySelector(formSelector);
        if (form) {
            form.addEventListener('submit', function(event) {
                event.preventDefault();

                var endTime = Date.now();
                var timeTaken = Math.floor((endTime - window[startTimeKey]) / 1000); // Time in seconds

                var formData = new FormData(form);
                formData.append('time_taken', timeTaken);
                formData.append('action', 'coco_form_submit');
                formData.append('security', settings.nonce);

                // Disable submit button to prevent multiple submissions
                var submitButton = form.querySelector('[type="submit"]');
                if (submitButton) {
                    submitButton.disabled = true;
                }

                fetch(settings.ajax_url, {
                    method: 'POST',
                    body: formData,
                    credentials: 'same-origin'
                })
                .then(function(response) {
                    return response.json();
                })
                .then(function(data) {
                    if (data.success) {
                        // Handle success (e.g., redirect or display a message)
                        if (data.data.redirect) {
                            window.location.href = data.data.redirect;
                        } else {
                            alert(data.data.message || 'Form submitted successfully!');
                            form.reset();
                        }

                        // Close popup if form is in a popup
                        if (isPopup) {
                            document.getElementById('coco-form-popup-overlay-' + formId).style.display = 'none';
                            document.getElementById('coco-form-popup-container-' + formId).style.display = 'none';
                        }
                    } else {
                        // Handle errors
                        alert(data.data.message || 'An error occurred. Please try again.');
                    }
                })
                .catch(function(error) {
                    console.error('Error:', error);
                    alert('An error occurred. Please try again.');
                })
                .finally(function() {
                    // Re-enable submit button
                    if (submitButton) {
                        submitButton.disabled = false;
                    }
                });
            });
        }
    }
});
