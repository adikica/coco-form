// assets/js/admin-script.js

jQuery(document).ready(function($) {
    // Handle spam entry details modal
    $('.view-details').on('click', function(e) {
        e.preventDefault();
        var entryId = $(this).data('entry-id');

        // AJAX request to fetch spam entry details
        $.ajax({
            url: ajaxurl,
            method: 'POST',
            data: {
                action: 'coco_form_get_spam_entry',
                entry_id: entryId,
                security: coco_form_admin_ajax_object.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#spam-entry-details').html(response.data.html);
                    $('#spam-entry-modal').show();
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    // Close modal
    $(document).on('click', '.spam-entry-content .close, #spam-entry-modal', function(e) {
        if ($(e.target).is('.close') || $(e.target).is('#spam-entry-modal')) {
            $('#spam-entry-modal').hide();
        }
    });
});
