coco-form/
├── coco-form.php
├── includes/
│   ├── class-coco-form.php
│   ├── class-coco-form-admin.php
│   ├── class-coco-form-frontend.php
│   ├── class-coco-form-ajax.php
│   ├── class-coco-form-helper.php
│   ├── class-coco-form-shortcodes.php
│   └── templates/
│       ├── admin-email/
│       │   ├── default.php
│       │   ├── template-1.php
│       │   ├── template-2.php
│       │   └── template-3.php
│       └── user-email/
│           ├── default.php
│           ├── template-1.php
│           ├── template-2.php
│           └── template-3.php
├── admin/
│   ├── class-coco-form-admin-menu.php
│   ├── class-coco-form-admin-settings.php
│   ├── partials/
│       ├── settings-page.php
│       ├── form-list-page.php
│       ├── form-edit-page.php
│       └── spam-entries-page.php
├── public/
│   ├── partials/
│       └── form-display.php
├── assets/
│   ├── css/
│       ├── admin-style.css
│       └── public-style.css
│   └── js/
│       ├── admin-script.js
│       └── public-script.js
└── languages/
    └── coco-form.pot
