<?php
// includes/class-coco-form-helper.php



defined('ABSPATH') || exit;

/**
 * Helper class for Coco Form plugin.
 */
class Coco_Form_Helper
{

    /**
     * Fired during plugin activation.
     */
    public static function activate()
    {
  
        self::create_database_tables();
    }

    /**
     * Fired during plugin deactivation.
     */
    public static function deactivate()
    {
        // Optional: Add deactivation logic if needed


    }

    /**
     * Create necessary database tables if they do not exist.
     */
    private static function create_database_tables()
    {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        $forms_table        = $wpdb->prefix . 'coco_forms';
        $entries_table      = $wpdb->prefix . 'coco_form_entries';
        $spam_entries_table = $wpdb->prefix . 'coco_spam_entries';

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Check if forms table exists, and create if it doesn't.
        if ($wpdb->get_var("SHOW TABLES LIKE '$forms_table'") != $forms_table) {
            $sql_forms = "CREATE TABLE $forms_table (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                form_name VARCHAR(255) NOT NULL,
                form_css TEXT NOT NULL,
                form_html TEXT NOT NULL,
                form_js TEXT NOT NULL,
                form_top TEXT NOT NULL,
                delay_time INT(11) NOT NULL,
                display_device VARCHAR(50) NOT NULL,
                is_active TINYINT(1) DEFAULT 0 NOT NULL,
                frequency INT(11) DEFAULT 1 NOT NULL,
                is_popup TINYINT(1) DEFAULT 0 NOT NULL,
                email_to VARCHAR(255) NOT NULL,
                email_from VARCHAR(255) NOT NULL,
                email_subject VARCHAR(255) NOT NULL,
                email_headers TEXT NOT NULL,
                email_body LONGTEXT NOT NULL,
                email_template LONGTEXT NOT NULL,
                form_redirect TEXT NOT NULL,
                form_wrapper_class TEXT NOT NULL,
                form_class TEXT NOT NULL,
                replay_template_choice VARCHAR(50) NOT NULL,
                admin_template_choice VARCHAR(50) NOT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;";
            dbDelta($sql_forms);
        }

        // Check if entries table exists, and create if it doesn't.
        if ($wpdb->get_var("SHOW TABLES LIKE '$entries_table'") != $entries_table) {
            $sql_entries = "CREATE TABLE $entries_table (
                entry_id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                form_id BIGINT(20) UNSIGNED NOT NULL,
                submission_date DATETIME DEFAULT '0000-00-00 00:00:00' NOT NULL,
                form_data LONGTEXT NOT NULL,
                PRIMARY KEY  (entry_id)
            ) $charset_collate;";
            dbDelta($sql_entries);
        }

        // Check if spam entries table exists, and create if it doesn't.
        if ($wpdb->get_var("SHOW TABLES LIKE '$spam_entries_table'") != $spam_entries_table) {
            $sql_spam = "CREATE TABLE $spam_entries_table (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                form_id BIGINT(20) UNSIGNED NOT NULL,
                submission_date DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL,
                email VARCHAR(255) NOT NULL,
                ip_address VARCHAR(45) NOT NULL,
                form_data LONGTEXT NOT NULL,
                spam_reason VARCHAR(255) NOT NULL,
                PRIMARY KEY (id)
            ) $charset_collate;";
            dbDelta($sql_spam);
        }
    }

    /**
     * Get allowed HTML tags for form rendering.
     *
     * @return array
     */
    // includes/class-coco-form-helper.php

    public static function get_allowed_html_tags()
    {
        return [
            'a' => [
                'href'   => [],
                'title'  => [],
                'class'  => [],
                'id'     => [],
                'target' => [],
                'rel'    => [],
            ],
            'br'       => [],
            'em'       => [],
            'strong'   => [],
            'input'    => [
                'type'        => [],
                'name'        => [],
                'value'       => [],
                'class'       => [],
                'id'          => [],
                'placeholder' => [],
                'required'    => [],
                'checked'     => [],
                'disabled'    => [],
                'readonly'    => [],
                'maxlength'   => [],
                'min'         => [],
                'max'         => [],
                'step'        => [],
                'size'        => [],
                'pattern'     => [],
                'multiple'    => [],
                'accept'      => [],
            ],
            'textarea' => [
                'name'        => [],
                'id'          => [],
                'class'       => [],
                'placeholder' => [],
                'required'    => [],
                'cols'        => [],
                'rows'        => [],
                'readonly'    => [],
                'disabled'    => [],
                'maxlength'   => [],
            ],
            'select'   => [
                'name'     => [],
                'id'       => [],
                'class'    => [],
                'required' => [],
                'disabled' => [],
                'multiple' => [],
            ],
            'option'   => [
                'value'    => [],
                'selected' => [],
                'disabled' => [],
            ],
            'label'    => [
                'for'   => [],
                'class' => [],
            ],
            'div'      => [
                'id'    => [],
                'class' => [],
                'style' => [],
            ],
            'span'     => [
                'id'    => [],
                'class' => [],
                'style' => [],
            ],
            'p'        => [
                'id'    => [],
                'class' => [],
                'style' => [],
            ],
            'h1'       => [
                'id'    => [],
                'class' => [],
                'style' => [],
            ],
            'h2'       => [
                'id'    => [],
                'class' => [],
                'style' => [],
            ],
            'h3'       => [
                'id'    => [],
                'class' => [],
                'style' => [],
            ],
            // Add more tags as needed
        ];
    }


    // Other helper methods can be added here.
}
