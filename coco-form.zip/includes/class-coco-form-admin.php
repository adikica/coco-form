<?php
// includes/class-coco-form-admin.php

defined( 'ABSPATH' ) || exit;

class Coco_Form_Admin {

    /**
     * Initialize admin functionality.
     */
    public function init() {
        $this->load_dependencies();
        $this->setup_hooks();
    }

    /**
     * Load admin dependencies.
     */
    private function load_dependencies() {
        require_once plugin_dir_path( __FILE__ ) . '../admin/class-coco-form-admin-menu.php';
        require_once plugin_dir_path( __FILE__ ) . '../admin/class-coco-form-admin-settings.php';
    }

    /**
     * Set up admin hooks.
     */
    private function setup_hooks() {
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
    }

    /**
     * Enqueue admin styles and scripts.
     */
    public function enqueue_admin_assets() {
        wp_enqueue_style( 'coco-form-admin-style', plugin_dir_url( __FILE__ ) . '../assets/css/admin-style.css', [], '1.0.0' );
        wp_enqueue_script( 'coco-form-admin-script', plugin_dir_url( __FILE__ ) . '../assets/js/admin-script.js', [ 'jquery' ], '1.0.0', true );
    }
}
