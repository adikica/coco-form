<?php
// includes/class-coco-form-frontend.php

defined('ABSPATH') || exit;

class Coco_Form_Frontend
{
    /**
     * Initialize frontend functionality.
     */
    public function init()
    {
        add_action('wp_enqueue_scripts', [$this, 'enqueue_public_assets']);
        add_action('wp_footer', [$this, 'output_inline_script']);
        
        // Centralize reCAPTCHA handling
        add_action('wp_head', [$this, 'enqueue_recaptcha_api']);
        add_action('wp_footer', [$this, 'setup_recaptcha_tokens']);
    }

    /**
     * Enqueue public styles and scripts.
     */
    public function enqueue_public_assets()
    {
        wp_enqueue_style('coco-form-public-style', plugin_dir_url(__FILE__) . '../assets/css/public-style.css', [], '1.0.0');
        wp_enqueue_script('coco-form-public-script', plugin_dir_url(__FILE__) . '../assets/js/public-script.js', ['jquery'], '1.0.0', true);

        // Localize script for AJAX URL, nonce, and reCAPTCHA site key
        $recaptcha_site_key = get_option('coco_form_recaptcha_site_key', '');
        
        wp_localize_script('coco-form-public-script', 'coco_form_ajax_object', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('coco_form_nonce'),
            'recaptcha_site_key' => $recaptcha_site_key,
            'has_recaptcha' => !empty($recaptcha_site_key)
        ]);
    }

    /**
     * Output inline script with form settings.
     */
    public function output_inline_script()
    {
        global $coco_forms_settings;

        if (!empty($coco_forms_settings)) {
            // Prepare the data as JSON
            $forms_settings_json = wp_json_encode($coco_forms_settings);

            // Output the inline script
            echo '<script>var coco_forms_settings = ' . $forms_settings_json . ';</script>';
        }
    }

    /**
     * Enqueue Google reCAPTCHA API script.
     */
    public function enqueue_recaptcha_api()
    {
        $recaptcha_site_key = get_option('coco_form_recaptcha_site_key');
        if ($recaptcha_site_key) {
            echo '<script src="https://www.google.com/recaptcha/api.js?render=' . esc_attr($recaptcha_site_key) . '"></script>';
        }
    }

    /**
     * Setup reCAPTCHA tokens for all forms.
     */
    public function setup_recaptcha_tokens()
    {
        $recaptcha_site_key = get_option('coco_form_recaptcha_site_key');
        if (!$recaptcha_site_key) {
            return;
        }
        ?>
        <script>
        (function() {
            // Use immediately invoked function expression (IIFE) to avoid global variable conflicts
            const cocoRecaptchaSiteKey = <?php echo json_encode($recaptcha_site_key); ?>;
            
            if (cocoRecaptchaSiteKey) {
                // Initialize reCAPTCHA once the page is ready
                grecaptcha.ready(function() {
                    // Function to refresh tokens
                    const refreshTokens = function() {
                        grecaptcha.execute(cocoRecaptchaSiteKey, {
                            action: 'form_submit'
                        }).then(function(token) {
                            // Update all reCAPTCHA input fields with the new token
                            document.querySelectorAll(".recaptchaResponse").forEach(elem => {
                                elem.value = token;
                            });
                        });
                    };
                    
                    // Initial token generation
                    refreshTokens();
                    
                    // Refresh tokens every 90 seconds (tokens expire after 2 minutes)
                    setInterval(refreshTokens, 90000);
                    
                    // Also refresh tokens when form submission is attempted
                    document.addEventListener('submit', function(e) {
                        if (e.target.classList.contains('coco-form')) {
                            // Prevent the default form submission
                            e.preventDefault();
                            
                            // Get a fresh token and then submit the form
                            grecaptcha.execute(cocoRecaptchaSiteKey, {
                                action: 'form_submit'
                            }).then(function(token) {
                                // Update the form's reCAPTCHA field
                                const recaptchaField = e.target.querySelector('.recaptchaResponse');
                                if (recaptchaField) {
                                    recaptchaField.value = token;
                                }
                                
                                // Now allow the form to be submitted
                                // This will be handled by your AJAX in public-script.js
                                jQuery(e.target).trigger('coco_form_submit_with_recaptcha');
                            });
                        }
                    }, false);
                });
            }
        })();
        </script>
        <?php
    }
}