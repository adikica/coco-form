<?php
// includes/class-coco-form.php

defined( 'ABSPATH' ) || exit;

class Coco_Form {

    /**
     * Run the plugin.
     */
    public function run() {
        $this->load_dependencies();
        $this->setup_hooks();
    }

    /**
     * Load all the plugin dependencies.
     */
    private function load_dependencies() {
        // Admin classes
        require_once plugin_dir_path( __FILE__ ) . 'class-coco-form-admin.php';
        require_once plugin_dir_path( __FILE__ ) . '../admin/class-coco-form-admin-menu.php';
        require_once plugin_dir_path( __FILE__ ) . '../admin/class-coco-form-admin-settings.php';

        // Frontend classes
        require_once plugin_dir_path( __FILE__ ) . 'class-coco-form-frontend.php';

        // AJAX handlers
        require_once plugin_dir_path( __FILE__ ) . 'class-coco-form-ajax.php';

        // Shortcodes
        require_once plugin_dir_path( __FILE__ ) . 'class-coco-form-shortcodes.php';

        // Helper functions
        require_once plugin_dir_path( __FILE__ ) . 'class-coco-form-helper.php';
    }

    /**
     * Set up all actions and filters.
     */
    private function setup_hooks() {
        // Load text domain for translations.
        add_action( 'plugins_loaded', [ $this, 'load_textdomain' ] );

     

        // Initialize admin and frontend functionality.
        if ( is_admin() ) {
            $plugin_admin = new Coco_Form_Admin();
            $plugin_admin->init();
        } else {
            $plugin_frontend = new Coco_Form_Frontend();
            $plugin_frontend->init();
        }

        // Initialize AJAX handlers.
        $plugin_ajax = new Coco_Form_Ajax();
        $plugin_ajax->init();

        // Initialize shortcodes.
        $plugin_shortcodes = new Coco_Form_Shortcodes();
        $plugin_shortcodes->init();
    }

    /**
     * Load the plugin text domain for translation.
     */
    public function load_textdomain() {
        load_plugin_textdomain( 'coco-form', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
    }
}
