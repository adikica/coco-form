<?php
// includes/templates/user-email/default.php

defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php esc_html_e( 'Thank You for Your Submission', 'coco-form' ); ?></title>
    <style>
        /* Optional: Add some basic styles */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
        }
        h2 {
            color: #2c7dfa;
        }
        .form-data {
            margin-top: 20px;
        }
        .form-data p {
            margin: 5px 0;
        }
        .form-data p strong {
            display: inline-block;
            width: 150px;
        }
    </style>
</head>
<body>
    <h2><?php esc_html_e( 'Thank You!', 'coco-form' ); ?></h2>
    <p><?php esc_html_e( 'We have received your submission and will get back to you shortly.', 'coco-form' ); ?></p>
    <!-- Uncomment the following section if you want to include the submitted data in the email -->
    <!--
    <div class="form-data">
        {form_data}
    </div>
    -->
</body>
</html>
