<?php
// includes/templates/form-display.php

defined('ABSPATH') || exit;
echo "<script>console.log(" . json_encode($form) . ");</script>";
?>

<?php

// Collect form settings in a global array
global $coco_forms_settings;
if (! isset($coco_forms_settings) || ! is_array($coco_forms_settings)) {
    $coco_forms_settings = [];
}

// Prepare form settings
$coco_forms_settings[$form->id] = [
    'ajax_url'       => admin_url('admin-ajax.php'),
    'nonce'          => wp_create_nonce('coco_form_nonce'),
    'form_id'        => $form->id,
    'is_popup'       => $form->is_popup,
    'delay_time'     => $form->delay_time,
    'frequency'      => $form->frequency,
    'display_device' => $form->display_device,
];

// Enqueue scripts and styles only once
if (! wp_script_is('coco-form-public-script', 'enqueued')) {
    wp_enqueue_style('coco-form-public-style');
    wp_enqueue_script('coco-form-public-script');
}
// Determine if the form should be displayed based on device
$display_form = true;
$device_type = wp_is_mobile() ? 'mobile' : 'desktop';


// Prepare form attributes
$form_attributes = [
    'id'    => 'coco-form-' . esc_attr($form->id),
    'class' => 'coco-form ' . esc_attr($form->form_class),
];

if ($form->display_device !== 'all' && $form->display_device !== $device_type) {
    $display_form = false;
}

if ($display_form) :
    // Output the form HTML
?>
    <?php if ($form->is_popup) : ?>
        <!-- Popup Form Structure -->
        <div id="coco-form-popup-overlay-<?php echo esc_attr($form->id); ?>" class="coco-form-popup-overlay" style="display: none;"></div>
        <div id="coco-form-popup-container-<?php echo esc_attr($form->id); ?>" class="coco-form-popup-container" style="display: none;">
            <button type="button" class="coco-form-close">&times;</button>
            <div class="coco-form-popup-content">
                <?php echo wp_kses_post($form->form_top); ?>
                <form <?php foreach ($form_attributes as $attr => $value) {
                            echo esc_attr($attr) . '="' . esc_attr($value) . '" ';
                        } ?>>
                    <?php
                    // Output form HTML
                    echo wp_kses($form->form_html, Coco_Form_Helper::get_allowed_html_tags());

                    // Add nonce field
                    wp_nonce_field('coco_form_nonce', 'security');

                    // Hidden fields
                    ?>
                    <input type="hidden" name="form_id" value="<?php echo esc_attr($form->id); ?>">
                    <input type="hidden" name="action" value="coco_form_submit">
                    <input type="hidden" name="time_taken" value="">
                    <input type="hidden" name="secretField" value="badValueEqualsBadClient">

                    <?php
                    $recaptcha_site_key = get_option('coco_form_recaptcha_site_key'); // Replace with your option retrieval method     
                    if ($recaptcha_site_key) {
                        echo '<input type="hidden" name="recaptcha_response" id="recaptchaResponse" class="recaptchaResponse">';
                    }
                    ?>
                </form>
            </div>
        </div>
    <?php else : ?>
        <!-- Inline Form Structure -->
        <div id="coco-form-container-<?php echo esc_attr($form->id); ?>" class="coco-form-container <?php echo esc_attr($form->form_wrapper_class); ?>">
            <?php echo wp_kses_post($form->form_top); ?>
            <form <?php foreach ($form_attributes as $attr => $value) {
                        echo esc_attr($attr) . '="' . esc_attr($value) . '" ';
                    } ?>>
                <?php
                // Output form HTML
                echo wp_kses($form->form_html, Coco_Form_Helper::get_allowed_html_tags());

                // Add nonce field
                wp_nonce_field('coco_form_nonce', 'security');

                // Hidden fields
                ?>
                <input type="hidden" name="form_id" value="<?php echo esc_attr($form->id); ?>">
                <input type="hidden" name="action" value="coco_form_submit">
                <input type="hidden" name="time_taken" value="">
                <input type="hidden" name="secretField" value="badValueEqualsBadClient">
                <?php
                $recaptcha_site_key = get_option('coco_form_recaptcha_site_key'); // Replace with your option retrieval method     
                if ($recaptcha_site_key) {
                    echo '<input type="hidden" name="recaptcha_response" id="recaptchaResponse" class="recaptchaResponse">';
                }
                ?>
            </form>
        </div>
    <?php endif; ?>
    <?php
    // Output any custom CSS
    if (! empty($form->form_css)) {
        echo '<style>' . wp_strip_all_tags($form->form_css) . '</style>';
    }

    // Output any custom JS
    if (! empty($form->form_js)) {
        echo '<script>' . wp_strip_all_tags($form->form_js) . '</script>';
    }
    ?>

    <!-- Initialize the form with JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize the form display logic
            if (typeof cocoFormInit === 'function') {
                cocoFormInit(<?php echo esc_attr($form->id); ?>);
            }
        });
    </script>

<?php
endif;
