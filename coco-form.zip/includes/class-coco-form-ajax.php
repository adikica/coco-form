<?php
// includes/class-coco-form-ajax.php

defined('ABSPATH') || exit;

/**
 * Handles AJAX requests for the Coco Form plugin.
 */
class Coco_Form_Ajax
{
    /**
     * Initialize AJAX handlers.
     */
    public function init()
    {
        // Handle form submission
        add_action('wp_ajax_coco_form_submit', [$this, 'handle_form_submission']);
        add_action('wp_ajax_nopriv_coco_form_submit', [$this, 'handle_form_submission']);

        // Fetch spam entry details
        add_action('wp_ajax_coco_form_get_spam_entry', [$this, 'get_spam_entry_details']);

        // Fetch form entry details
        add_action('wp_ajax_coco_form_get_entry', [$this, 'get_form_entry_details']);
    }

    /**
     * Handle form submission via AJAX.
     */
    public function handle_form_submission()
    {
        // Verify nonce
        check_ajax_referer('coco_form_nonce', 'security');

        // Collect and sanitize form data
        $form_id = isset($_POST['form_id']) ? intval($_POST['form_id']) : 0;
        if (!$form_id) {
            wp_send_json_error(__('Invalid form ID.', 'coco-form'));
        }

        // Get the form details
        global $wpdb;
        $forms_table = $wpdb->prefix . 'coco_forms';
        $form = $wpdb->get_row($wpdb->prepare("SELECT * FROM $forms_table WHERE id = %d", $form_id));

        if (!$form || !$form->is_active) {
            wp_send_json_error(__('Form is not active or does not exist.', 'coco-form'));
        }

        // Collect form data, excluding internal fields
        $excluded_fields = ['action', 'security', 'form_id', 'secretField', 'recaptcha_response'];

        $form_data = [];
        foreach ($_POST as $key => $value) {
            if (!in_array($key, $excluded_fields, true)) {
                $form_data[sanitize_text_field($key)] = sanitize_textarea_field($value);
            }
        }

        // Get user's IP address
        $ip_address = $this->get_user_ip();

        // Get email from form data, if available
        $email = isset($form_data['email']) ? sanitize_email($form_data['email']) : '';

        // Spam checks
        if ($this->is_spam_submission($form_id, $form_data, $email, $ip_address)) {
            wp_send_json_error(__('Your submission was flagged as spam.', 'coco-form'));
        }

        // Save the form entry
        $this->save_form_entry($form_id, $form_data);

        // Send emails
        $this->send_emails($form, $form_data, $email);

        // Success response
        wp_send_json_success([
            'message'  => __('Form submitted successfully!', 'coco-form'),
            'redirect' => $form->form_redirect ? esc_url_raw($form->form_redirect) : '',
        ]);
    }

    /**
     * Check if the submission is spam.
     *
     * @param int    $form_id
     * @param array  $form_data
     * @param string $email
     * @param string $ip_address
     * @return bool
     */
    private function is_spam_submission($form_id, $form_data, $email, $ip_address)
    {
        // Check reCAPTCHA if enabled
        if (!$this->verify_recaptcha()) {
            $this->log_spam_entry($form_id, $form_data, $email, $ip_address, 'Failed reCAPTCHA verification');
            return true;
        }

        // Verify honeypot field
        if (!isset($_POST['secretField']) || $_POST['secretField'] !== 'badValueEqualsBadClient') {
            $this->log_spam_entry($form_id, $form_data, $email, $ip_address, 'Failed honeypot check');
            return true;
        }

        // Verify time taken to fill the form
        $time_taken = isset($_POST['time_taken']) ? intval($_POST['time_taken']) : 0;
        if ($time_taken < 5) { // If form is submitted in less than 5 seconds, consider it spam
            $this->log_spam_entry($form_id, $form_data, $email, $ip_address, 'Form submitted too quickly');
            return true;
        }

        // Check disallowed words in form data
        if ($this->contains_disallowed_words($form_data)) {
            $this->log_spam_entry($form_id, $form_data, $email, $ip_address, 'Contains disallowed words');
            return true;
        }

        // Check allowed email providers
        if (!$this->is_allowed_email_provider($email)) {
            $this->log_spam_entry($form_id, $form_data, $email, $ip_address, 'Email provider not allowed');
            return true;
        }

        return false; // Not spam
    }

    /**
     * Log spam entry to the database.
     *
     * @param int    $form_id
     * @param array  $form_data
     * @param string $email
     * @param string $ip_address
     * @param string $reason
     */
    private function log_spam_entry($form_id, $form_data, $email, $ip_address, $reason)
    {
        global $wpdb;
        $spam_table = $wpdb->prefix . 'coco_spam_entries';
        $wpdb->insert($spam_table, [
            'form_id'         => $form_id,
            'submission_date' => current_time('mysql'),
            'email'           => $email,
            'ip_address'      => $ip_address,
            'form_data'       => wp_json_encode($form_data),
            'spam_reason'     => sanitize_text_field($reason),
        ]);
    }

    /**
     * Save form entry to the database.
     *
     * @param int   $form_id
     * @param array $form_data
     */
    private function save_form_entry($form_id, $form_data)
    {
        global $wpdb;
        $entries_table = $wpdb->prefix . 'coco_form_entries';
        $wpdb->insert($entries_table, [
            'form_id'          => $form_id,
            'submission_date'  => current_time('mysql'),
            'form_data'        => wp_json_encode($form_data),
        ]);
    }

    /**
     * Send emails after form submission.
     *
     * @param object $form
     * @param array  $form_data
     * @param string $user_email
     */
    private function send_emails($form, $form_data, $user_email)
    {
        // Send email to admin
        if (!empty($form->email_to)) {
            $this->send_admin_email($form, $form_data);
        }

        // Send thank-you email to user
        if (!empty($user_email)) {
            $this->send_user_email($form, $form_data, $user_email);
        }
    }

    /**
     * Send email to admin.
     *
     * @param object $form
     * @param array  $form_data
     */
    private function send_admin_email($form, $form_data)
    {
        // Prepare email headers
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        if (!empty($form->email_from)) {
            $headers[] = 'From: ' . sanitize_email($form->email_from);
        }

        // Prepare email subject
        $subject = !empty($form->email_subject) ? sanitize_text_field($form->email_subject) : __('New Form Submission', 'coco-form');

        // Prepare email content
        $email_content = $this->render_email_template($form_data, $form->admin_template_choice, 'admin');

        // Send the email
        wp_mail(sanitize_email($form->email_to), $subject, $email_content, $headers);
    }

    /**
     * Send thank-you email to user.
     *
     * @param object $form
     * @param array  $form_data
     * @param string $user_email
     */
    private function send_user_email($form, $form_data, $user_email)
    {
        // Prepare email headers
        $headers = ['Content-Type: text/html; charset=UTF-8'];
        if (!empty($form->email_from)) {
            $headers[] = 'From: ' . sanitize_email($form->email_from);
        }

        // Prepare email subject
        $subject = __('Thank you for your submission', 'coco-form');

        // Prepare email content
        $email_content = $this->render_email_template($form_data, $form->replay_template_choice, 'user');

        // Send the email
        wp_mail($user_email, $subject, $email_content, $headers);
    }

    /**
     * Render email template.
     *
     * @param array  $form_data
     * @param string $template_choice
     * @param string $type            'admin' or 'user'
     * @return string
     */
    private function render_email_template($form_data, $template_choice, $type = 'admin')
    {
        // Determine template path
        $template_dir = plugin_dir_path(__FILE__) . 'templates/';
        $template_subdir = $type === 'admin' ? 'admin-email/' : 'user-email/';
        $template_file = $template_dir . $template_subdir . $template_choice . '.php';

        // Fallback to default template if file doesn't exist
        if (!file_exists($template_file)) {
            $template_file = $template_dir . $template_subdir . 'default.php';
        }

        // Generate the form data HTML
        $form_data_html = '';
        foreach ($form_data as $key => $value) {
            $label = ucfirst(str_replace('_', ' ', $key));
            $form_data_html .= '<p><strong>' . esc_html($label) . ':</strong> ' . nl2br(esc_html($value)) . '</p>';
        }

        // Capture the template output
        ob_start();
        include $template_file;
        $email_content = ob_get_clean();

        // Replace placeholders
        $email_content = str_replace('{form_data}', $form_data_html, $email_content);

        return $email_content;
    }

    /**
     * Get user's IP address.
     *
     * @return string
     */
    private function get_user_ip()
    {
        $ip = '';
        
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = sanitize_text_field($_SERVER['HTTP_CLIENT_IP']);
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // Get the first IP in case of multiple proxies
            $ip_list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            $ip = sanitize_text_field(trim($ip_list[0]));
        } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
            $ip = sanitize_text_field($_SERVER['REMOTE_ADDR']);
        }
        
        // Make sure the IP is in a valid format
        return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
    }

    /**
     * Fetch spam entry details via AJAX.
     */
    public function get_spam_entry_details()
    {
        // Verify nonce
        check_ajax_referer('coco_form_get_spam_entry', 'security');

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'coco-form')]);
        }

        // Validate entry ID
        if (!isset($_POST['entry_id'])) {
            wp_send_json_error(['message' => __('Invalid entry ID.', 'coco-form')]);
        }

        $entry_id = intval($_POST['entry_id']);

        // Fetch the spam entry
        global $wpdb;
        $spam_table = $wpdb->prefix . 'coco_spam_entries';
        $entry = $wpdb->get_row($wpdb->prepare("SELECT * FROM $spam_table WHERE id = %d", $entry_id));

        if (!$entry) {
            wp_send_json_error(['message' => __('Entry not found.', 'coco-form')]);
        }

        // Decode form data
        $form_data = json_decode($entry->form_data, true);

        // Prepare HTML output
        ob_start();
?>
        <h2><?php esc_html_e('Spam Entry Details', 'coco-form'); ?></h2>
        <p><strong><?php esc_html_e('Spam Reason:', 'coco-form'); ?></strong> <?php echo esc_html($entry->spam_reason); ?></p>
        <table class="wp-list-table widefat fixed striped">
            <tbody>
                <?php foreach ($form_data as $key => $value) : ?>
                    <tr>
                        <th><?php echo esc_html(ucfirst(str_replace('_', ' ', $key))); ?></th>
                        <td><?php echo nl2br(esc_html($value)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
<?php
        $html = ob_get_clean();

        wp_send_json_success(['html' => $html]);
    }

    /**
     * Fetch form entry details via AJAX.
     */
    public function get_form_entry_details()
    {
        // Verify nonce
        check_ajax_referer('coco_form_get_entry', 'security');

        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied.', 'coco-form')]);
        }

        // Validate entry ID
        if (!isset($_POST['entry_id'])) {
            wp_send_json_error(['message' => __('Invalid entry ID.', 'coco-form')]);
        }

        $entry_id = intval($_POST['entry_id']);

        // Fetch the form entry
        global $wpdb;
        $entries_table = $wpdb->prefix . 'coco_form_entries';
        $entry = $wpdb->get_row($wpdb->prepare("SELECT * FROM $entries_table WHERE entry_id = %d", $entry_id));

        if (!$entry) {
            wp_send_json_error(['message' => __('Entry not found.', 'coco-form')]);
        }

        // Decode form data
        $form_data = json_decode($entry->form_data, true);

        // Prepare HTML output
        ob_start();
?>
        <h2><?php esc_html_e('Form Entry Details', 'coco-form'); ?></h2>
        <table class="wp-list-table widefat fixed striped">
            <tbody>
                <?php foreach ($form_data as $key => $value) : ?>
                    <tr>
                        <th><?php echo esc_html(ucfirst(str_replace('_', ' ', $key))); ?></th>
                        <td><?php echo nl2br(esc_html($value)); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
<?php
        $html = ob_get_clean();

        wp_send_json_success(['html' => $html]);
    }

    /**
     * Verify Google reCAPTCHA.
     *
     * @return bool
     */
    private function verify_recaptcha()
    {
        // Get reCAPTCHA keys from settings
        $site_key   = get_option('coco_form_recaptcha_site_key', '');
        $secret_key = get_option('coco_form_recaptcha_secret_key', '');

        // If keys are not set, skip reCAPTCHA verification
        if (empty($site_key) || empty($secret_key)) {
            return true;
        }

        // Verify reCAPTCHA response
        if (isset($_POST['recaptcha_response']) && !empty($_POST['recaptcha_response'])) {
            $response = wp_remote_post('https://www.google.com/recaptcha/api/siteverify', [
                'body' => [
                    'secret'   => $secret_key,
                    'response' => sanitize_text_field($_POST['recaptcha_response']),
                    'remoteip' => $this->get_user_ip(),
                ],
            ]);

            if (is_wp_error($response)) {
                // Log the error for debugging
                error_log('reCAPTCHA verification failed: ' . $response->get_error_message());
                return false;
            }

            $response_body = wp_remote_retrieve_body($response);
            $result = json_decode($response_body, true);

            // Check both success and score for v3
            if (isset($result['success']) && $result['success'] === true) {
                // For v3, verify the score (0.0 is bot, 1.0 is human)
                if (isset($result['score'])) {
                    // Get minimum score from settings or use default 0.5
                    $min_score = get_option('coco_form_recaptcha_min_score', 0.5);
                    return $result['score'] >= floatval($min_score);
                }
                return true;
            }
            
            // Log the reason for failure
            if (isset($result['error-codes'])) {
                error_log('reCAPTCHA verification failed: ' . implode(', ', $result['error-codes']));
            }
            
            return false;
        }

        return false;
    }

    /**
     * Check if form data contains disallowed words.
     *
     * @param array $form_data
     * @return bool
     */
    private function contains_disallowed_words($form_data)
    {
        $disallowed_words_option = get_option('coco_form_disallowed_words', '');
        $disallowed_words = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $disallowed_words_option)));

        if (empty($disallowed_words)) {
            return false;
        }

        $message = implode(' ', $form_data);
        $message = strtolower($message);

        foreach ($disallowed_words as $word) {
            if (strpos($message, strtolower($word)) !== false) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if the email is from an allowed provider.
     *
     * @param string $email
     * @return bool
     */
    private function is_allowed_email_provider($email)
    {
        $allowed_providers_option = get_option('coco_form_allowed_email_providers', '');
        $allowed_providers = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $allowed_providers_option)));

        if (empty($allowed_providers) || empty($email)) {
            return true;
        }

        $email_domain = substr(strrchr($email, '@'), 1);

        return in_array($email_domain, $allowed_providers, true);
    }
}