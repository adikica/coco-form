<?php
// includes/class-coco-form-shortcodes.php

defined( 'ABSPATH' ) || exit;

class Coco_Form_Shortcodes {

    /**
     * Initialize shortcodes.
     */
    public function init() {
        add_shortcode( 'coco_form', [ $this, 'render_form_shortcode' ] );
    }

    /**
     * Render the form via shortcode.
     *
     * @param array $atts Shortcode attributes.
     * @return string
     */
    public function render_form_shortcode( $atts ) {
        $atts = shortcode_atts( [ 'id' => 0 ], $atts, 'coco_form' );
        $form_id = intval( $atts['id'] );

        if ( ! $form_id ) {
            return '';
        }

        global $wpdb;
        $forms_table = $wpdb->prefix . 'coco_forms';
        $form = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $forms_table WHERE id = %d", $form_id ) );

        if ( ! $form || ! $form->is_active ) {
            return '';
        }

        // Prepare form HTML.
        ob_start();
        include plugin_dir_path( __FILE__ ) . 'templates/form-display.php';
       //include plugin_dir_path( __FILE__ ) . '../public/partials/form-display.php';
        return ob_get_clean();
    }
}
