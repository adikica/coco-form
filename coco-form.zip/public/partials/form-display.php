<?php
// includes/templates/form-display.php

defined( 'ABSPATH' ) || exit;

// Enqueue necessary scripts and styles
wp_enqueue_style( 'coco-form-public-style' );
wp_enqueue_script( 'coco-form-public-script' );

// Localize script with AJAX URL and nonce
wp_localize_script( 'coco-form-public-script', 'coco_form_ajax_object', [
    'ajax_url' => admin_url( 'admin-ajax.php' ),
    'nonce'    => wp_create_nonce( 'coco_form_nonce' ),
    'form_id'  => $form->id,
] );

// Prepare form attributes
$form_attributes = [
    'id'    => 'coco-form-' . esc_attr( $form->id ),
    'class' => 'coco-form ' . esc_attr( $form->form_class ),
];

// Start output buffering
ob_start();
?>

<div id="coco-form-container-<?php echo esc_attr( $form->id ); ?>" class="coco-form-container <?php echo esc_attr( $form->form_wrapper_class ); ?> <?php echo esc_attr( $form->is_popup ); ?>">
    <?php echo wp_kses_post( $form->form_top ); ?>
    <form <?php foreach ( $form_attributes as $attr => $value ) { echo esc_attr( $attr ) . '="' . esc_attr( $value ) . '" '; } ?>>
        <?php
        // Output form HTML
        echo wp_kses( $form->form_html, Coco_Form_Helper::get_allowed_html_tags() );

        // Add nonce field
        wp_nonce_field( 'coco_form_nonce', 'security' );

        // Hidden fields
        ?>
        <input type="hidden" name="form_id" value="<?php echo esc_attr( $form->id ); ?>">
        <input type="hidden" name="action" value="coco_form_submit">
        <input type="hidden" name="time_taken" value="">
        <input type="hidden" name="secretField" value="badValueEqualsBadClient">
    </form>
</div>

<?php
// Output any custom CSS
if ( ! empty( $form->form_css ) ) {
    echo '<style>' . wp_strip_all_tags( $form->form_css ) . '</style>';
}

// Output any custom JS
if ( ! empty( $form->form_js ) ) {
    echo '<script>' . wp_strip_all_tags( $form->form_js ) . '</script>';
}

return ob_get_clean();
