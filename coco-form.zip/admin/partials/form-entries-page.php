<?php
// admin/partials/form-entries-page.php

defined( 'ABSPATH' ) || exit;

// Check user permissions
if ( ! current_user_can( 'manage_options' ) ) {
    return;
}

global $wpdb;
$entries_table = $wpdb->prefix . 'coco_form_entries';
$forms_table   = $wpdb->prefix . 'coco_forms';

// Handle entry deletion
if ( isset( $_GET['action'], $_GET['entry_id'] ) && $_GET['action'] === 'delete' && wp_verify_nonce( $_GET['_wpnonce'], 'coco_form_delete_entry' ) ) {
    $entry_id = intval( $_GET['entry_id'] );
    $wpdb->delete( $entries_table, [ 'entry_id' => $entry_id ], [ '%d' ] );
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Entry deleted successfully.', 'coco-form' ) . '</p></div>';
}

// Retrieve all entries
$entries = $wpdb->get_results( "SELECT * FROM $entries_table ORDER BY submission_date DESC" );

// Get form names for display
$form_names = $wpdb->get_results( "SELECT id, form_name FROM $forms_table", OBJECT_K );
?>

<div class="wrap">
    <h1><?php esc_html_e( 'Form Entries', 'coco-form' ); ?></h1>

    <?php if ( $entries ) : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'Entry ID', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Form Name', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Submission Date', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Actions', 'coco-form' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $entries as $entry ) : ?>
                    <tr>
                        <td><?php echo esc_html( $entry->entry_id ); ?></td>
                        <td><?php echo isset( $form_names[ $entry->form_id ] ) ? esc_html( $form_names[ $entry->form_id ]->form_name ) : esc_html__( 'Unknown', 'coco-form' ); ?></td>
                        <td><?php echo esc_html( $entry->submission_date ); ?></td>
                        <td>
                            <a href="#" class="view-entry-details" data-entry-id="<?php echo esc_attr( $entry->entry_id ); ?>"><?php esc_html_e( 'View', 'coco-form' ); ?></a> |
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=coco-form-entries&action=delete&entry_id=' . $entry->entry_id ), 'coco_form_delete_entry' ) ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this entry?', 'coco-form' ); ?>');"><?php esc_html_e( 'Delete', 'coco-form' ); ?></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Modal for viewing entry details -->
        <div id="entry-modal" style="display: none;">
            <div class="entry-modal-content">
                <span class="close">&times;</span>
                <div id="entry-details"></div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('.view-entry-details').on('click', function(e) {
                e.preventDefault();
                var entryId = $(this).data('entry-id');

                // AJAX request to fetch entry details
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'coco_form_get_entry',
                        entry_id: entryId,
                        security: '<?php echo wp_create_nonce( 'coco_form_get_entry' ); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#entry-details').html(response.data.html);
                            $('#entry-modal').show();
                        } else {
                            alert(response.data.message);
                        }
                    }
                });
            });

            // Close modal
            $(document).on('click', '.entry-modal-content .close, #entry-modal', function(e) {
                if ($(e.target).is('.close') || $(e.target).is('#entry-modal')) {
                    $('#entry-modal').hide();
                }
            });
        });
        </script>
    <?php else : ?>
        <p><?php esc_html_e( 'No entries found.', 'coco-form' ); ?></p>
    <?php endif; ?>
</div>
