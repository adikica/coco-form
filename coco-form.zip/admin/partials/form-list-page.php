<?php
// admin/partials/form-list-page.php

defined( 'ABSPATH' ) || exit;

// Check user permissions
if ( ! current_user_can( 'manage_options' ) ) {
    return;
}

global $wpdb;
$forms_table = $wpdb->prefix . 'coco_forms';

// Handle form deletion
if ( isset( $_GET['action'], $_GET['form_id'] ) && $_GET['action'] === 'delete' && wp_verify_nonce( $_GET['_wpnonce'], 'coco_form_delete_form' ) ) {
    $form_id = intval( $_GET['form_id'] );
    $wpdb->delete( $forms_table, [ 'id' => $form_id ], [ '%d' ] );
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Form deleted successfully.', 'coco-form' ) . '</p></div>';
}

// Retrieve all forms
$forms = $wpdb->get_results( "SELECT * FROM $forms_table" );
?>

<div class="wrap">
    <h1>
        <?php esc_html_e( 'Forms', 'coco-form' ); ?>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=coco-form-add' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Add New', 'coco-form' ); ?></a>
    </h1>

    <?php if ( $forms ) : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'ID', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Form Name', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Shortcode', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Active', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Actions', 'coco-form' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $forms as $form ) : ?>
                    <tr>
                        <td><?php echo esc_html( $form->id ); ?></td>
                        <td><?php echo esc_html( $form->form_name ); ?></td>
                        <td><code>[coco_form id="<?php echo esc_attr( $form->id ); ?>"]</code></td>
                        <td><?php echo $form->is_active ? esc_html__( 'Yes', 'coco-form' ) : esc_html__( 'No', 'coco-form' ); ?></td>
                        <td>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=coco-form-add&form_id=' . $form->id ) ); ?>"><?php esc_html_e( 'Edit', 'coco-form' ); ?></a> |
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=coco-form&action=delete&form_id=' . $form->id ), 'coco_form_delete_form' ) ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this form?', 'coco-form' ); ?>');"><?php esc_html_e( 'Delete', 'coco-form' ); ?></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else : ?>
        <p><?php esc_html_e( 'No forms found.', 'coco-form' ); ?></p>
    <?php endif; ?>
</div>
