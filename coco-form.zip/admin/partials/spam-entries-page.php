<?php
// admin/partials/spam-entries-page.php

defined( 'ABSPATH' ) || exit;

// Check user permissions
if ( ! current_user_can( 'manage_options' ) ) {
    return;
}

global $wpdb;
$spam_table = $wpdb->prefix . 'coco_spam_entries';

// Handle spam entry deletion
if ( isset( $_GET['action'], $_GET['entry_id'] ) && $_GET['action'] === 'delete' && wp_verify_nonce( $_GET['_wpnonce'], 'coco_form_delete_spam_entry' ) ) {
    $entry_id = intval( $_GET['entry_id'] );
    $wpdb->delete( $spam_table, [ 'id' => $entry_id ], [ '%d' ] );
    echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Spam entry deleted successfully.', 'coco-form' ) . '</p></div>';
}

if (isset($_GET['action']) && $_GET['action'] === 'mark_legitimate' && isset($_GET['spam_id'])) {
    $spam_id = intval($_GET['spam_id']);

    // Mark spam as legitimate (placeholder for your function)
    // mark_spam_as_legitimate($spam_id);
mark_spam_as_legitimate($spam_id); // Ensure this function is defined and error-free

    // Redirect safely
    wp_redirect(admin_url('admin.php?page=spam-entries'));
    exit;
}

function build_email_body($form_data) {
    $body = "<h3>New Form Submission</h3>";
    foreach ($form_data as $field => $value) {
        $body .= "<p><strong>" . esc_html($field) . ":</strong> " . esc_html($value) . "</p>";
    }
    return $body;
}

function mark_spam_as_legitimate($spam_id) {
    global $wpdb;

    $spam_table = $wpdb->prefix . 'coco_spam_entries';
    $entries_table = $wpdb->prefix . 'coco_form_entries';
    $forms_table = $wpdb->prefix . 'coco_forms';

    // Retrieve the spam entry
    $spam_entry = $wpdb->get_row($wpdb->prepare("SELECT * FROM $spam_table WHERE id = %d", $spam_id));
    if (!$spam_entry) {
        wp_die(__('Spam entry not found', 'coco-form'));
    }

    // Decode the form data
    $form_data = json_decode($spam_entry->form_data, true);
    if (!$form_data) {
        wp_die(__('Invalid form data', 'coco-form'));
    }

    // Save the entry to the legitimate entries table
    $wpdb->insert($entries_table, [
        'form_id'         => $spam_entry->form_id,
        'submission_date' => $spam_entry->submission_date,
        'form_data'       => $spam_entry->form_data
    ]);

    if ($wpdb->last_error) {
        wp_die(__('Failed to save legitimate entry', 'coco-form'));
    }

    // Retrieve form details
    $form = $wpdb->get_row($wpdb->prepare("SELECT * FROM $forms_table WHERE id = %d", $spam_entry->form_id));
    if (!$form) {
        wp_die(__('Form configuration not found', 'coco-form'));
    }

    // Prepare email details
    $email_subject = !empty($form->email_subject) ? sanitize_text_field($form->email_subject) : 'New Form Submission';
    $email_to = sanitize_email($form->email_to);
    $email_body = build_email_body($form_data); // Use a helper function to format the email body

    // Set "From" header
    $email_from = !empty($form->email_from) ? sanitize_email($form->email_from) : get_option('admin_email');
    $headers = [
        'From: ' . $email_from,
        'Content-Type: text/html; charset=utf-8'
    ];

    // Add additional headers if provided
    if (!empty($form->email_headers)) {
        $additional_headers = explode("\n", wp_strip_all_tags($form->email_headers));
        $headers = array_merge($headers, $additional_headers);
    }

    // Send the email
    $email_sent = wp_mail($email_to, $email_subject, $email_body, $headers);
    if (!$email_sent) {
        wp_die(__('Failed to send email', 'coco-form'));
    }

    // Delete the spam entry
    $wpdb->delete($spam_table, ['id' => $spam_id]);
    if ($wpdb->last_error) {
        wp_die(__('Failed to delete spam entry', 'coco-form'));
    }

    wp_redirect(admin_url('admin.php?page=spam-entries'));
    exit;
}



// Retrieve spam entries
$entries = $wpdb->get_results( "SELECT * FROM $spam_table ORDER BY submission_date DESC" );
?>

<div class="wrap">
    <h1><?php esc_html_e( 'Spam Entries', 'coco-form' ); ?></h1>

    <?php if ( $entries ) : ?>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th><?php esc_html_e( 'ID', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Form ID', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Submission Date', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Email', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'IP Address', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Spam Reason', 'coco-form' ); ?></th>
                    <th><?php esc_html_e( 'Actions', 'coco-form' ); ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ( $entries as $entry ) : ?>
                    <tr>
                        <td><?php echo esc_html( $entry->id ); ?></td>
                        <td><?php echo esc_html( $entry->form_id ); ?></td>
                        <td><?php echo esc_html( $entry->submission_date ); ?></td>
                        <td><?php echo esc_html( $entry->email ); ?></td>
                        <td><?php echo esc_html( $entry->ip_address ); ?></td>
                        <td><?php echo esc_html( $entry->spam_reason ); ?></td>
                        <td>
                        <a href="<?php echo add_query_arg(['action' => 'mark_legitimate', 'spam_id' => $entry->id]); ?>">Mark as Legitimate</a> | 
                            <a href="#" class="view-details" data-entry-id="<?php echo esc_attr( $entry->id ); ?>"><?php esc_html_e( 'View Details', 'coco-form' ); ?></a> |
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=coco-form-spam&action=delete&entry_id=' . $entry->id ), 'coco_form_delete_spam_entry' ) ); ?>" onclick="return confirm('<?php esc_attr_e( 'Are you sure you want to delete this spam entry?', 'coco-form' ); ?>');"><?php esc_html_e( 'Delete', 'coco-form' ); ?></a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Modal for viewing spam entry details -->
        <div id="spam-entry-modal" style="display: none;">
            <div class="spam-entry-content">
                <span class="close">&times;</span>
                <div id="spam-entry-details"></div>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            $('.view-details').on('click', function(e) {
                e.preventDefault();
                var entryId = $(this).data('entry-id');

                // AJAX request to fetch spam entry details
                $.ajax({
                    url: ajaxurl,
                    method: 'POST',
                    data: {
                        action: 'coco_form_get_spam_entry',
                        entry_id: entryId,
                        security: '<?php echo wp_create_nonce( 'coco_form_get_spam_entry' ); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#spam-entry-details').html(response.data.html);
                            $('#spam-entry-modal').show();
                        } else {
                            alert(response.data.message);
                        }
                    }
                });
            });

            // Close modal
            $('.close').on('click', function() {
                $('#spam-entry-modal').hide();
            });
        });
        </script>
    <?php else : ?>
        <p><?php esc_html_e( 'No spam entries found.', 'coco-form' ); ?></p>
    <?php endif; ?>
</div>
