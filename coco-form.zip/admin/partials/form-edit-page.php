<?php
// admin/partials/form-edit-page.php

defined( 'ABSPATH' ) || exit;

// Check user permissions
if ( ! current_user_can( 'manage_options' ) ) {
    return;
}

global $wpdb;
$forms_table = $wpdb->prefix . 'coco_forms';

// Check if we're editing an existing form
$form_id = isset( $_GET['form_id'] ) ? intval( $_GET['form_id'] ) : 0;
$form    = null;

if ( $form_id ) {
    $form = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $forms_table WHERE id = %d", $form_id ) );
}

// Handle form submission
if ( isset( $_POST['coco_form_nonce'] ) && wp_verify_nonce( $_POST['coco_form_nonce'], 'coco_form_save_form' ) ) {
    $data = [
        'form_name'                => sanitize_text_field( $_POST['form_name'] ),
        'form_css'                  => wp_unslash( $_POST['form_css'] ),
        'form_html'                 => wp_unslash($_POST['form_html']),
        'form_js'                  => wp_unslash( $_POST['form_js'] ),
        'form_top'                 => wp_kses_post( $_POST['form_top'] ),
        'delay_time'               => intval( $_POST['delay_time'] ),
        'display_device'           => sanitize_text_field( $_POST['display_device'] ),
        'is_active'                => isset( $_POST['is_active'] ) ? 1 : 0,
        'frequency'                => $_POST['frequency'] === 'default' ? 'default' : intval( $_POST['frequency'] ),
        'is_popup'                 => isset( $_POST['is_popup'] ) ? 1 : 0,
        'email_to'                 => sanitize_email( $_POST['email_to'] ),
        'email_from'               => sanitize_email( $_POST['email_from'] ),
        'email_subject'            => sanitize_text_field( $_POST['email_subject'] ),
        'email_headers'            => wp_kses_post( $_POST['email_headers'] ),
        'form_redirect'            => esc_url_raw( $_POST['form_redirect'] ),
        'form_wrapper_class'       => sanitize_text_field( $_POST['form_wrapper_class'] ),
        'form_class'               => sanitize_text_field( $_POST['form_class'] ),
        'replay_template_choice'   => sanitize_text_field( $_POST['replay_template_choice'] ),
        'admin_template_choice'    => sanitize_text_field( $_POST['admin_template_choice'] ),
    ];

    if ( $form_id ) {
        // Update existing form
        $wpdb->update( $forms_table, $data, [ 'id' => $form_id ], null, [ '%d' ] );
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Form updated successfully.', 'coco-form' ) . '</p></div>';
    } else {
        // Insert new form
        $wpdb->insert( $forms_table, $data );
        $form_id = $wpdb->insert_id;
        echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Form created successfully.', 'coco-form' ) . '</p></div>';
    }

    // Reload form data
    $form = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $forms_table WHERE id = %d", $form_id ) );
}

// If form is still null, initialize an empty object
if ( ! $form ) {
    $form = (object) [
        'form_name'              => '',
        'form_css'               => '',
        'form_html'              => '',
        'form_js'                => '',
        'form_top'               => '',
        'delay_time'             => 0,
        'display_device'         => 'all',
        'is_active'              => 1,
        'frequency'              => 'default',
        'is_popup'               => 0,
        'email_to'               => '',
        'email_from'             => '',
        'email_subject'          => '',
        'email_headers'          => '',
        'form_redirect'          => '',
        'form_wrapper_class'     => '',
        'form_class'             => '',
        'replay_template_choice' => 'default',
        'admin_template_choice'  => 'default',
    ];
}
?>

<div class="wrap coco-backend-new">
    <h1><?php echo $form_id ? esc_html__( 'Edit Form', 'coco-form' ) : esc_html__( 'Create New Form', 'coco-form' ); ?></h1>
    <form method="post" action="">
        <?php wp_nonce_field( 'coco_form_save_form', 'coco_form_nonce' ); ?>

        <!-- Form fields -->
        <div class="coco-form-field coco-25-field">
            <label for="form_name"><?php esc_html_e( 'Form Name', 'coco-form' ); ?></label>
            <input type="text" name="form_name" value="<?php echo esc_attr( $form->form_name ); ?>" required>
        </div>

        <!-- Email Settings -->
        <div class="coco-form-field coco-25-field">
            <label for="email_to"><?php esc_html_e( 'Email To', 'coco-form' ); ?></label>
            <input type="email" name="email_to" value="<?php echo esc_attr( $form->email_to ); ?>" required>
        </div>

        <div class="coco-form-field coco-25-field">
            <label for="email_subject"><?php esc_html_e( 'Email Subject', 'coco-form' ); ?></label>
            <input type="text" name="email_subject" value="<?php echo esc_attr( $form->email_subject ); ?>" required>
        </div>

        <div class="coco-form-field coco-25-field">
            <label for="email_from"><?php esc_html_e( 'Email From', 'coco-form' ); ?></label>
            <input type="email" name="email_from" value="<?php echo esc_attr( $form->email_from ); ?>" required>
        </div>

        <!-- Form HTML -->
        <div class="coco-form-field coco-100-field">
            <label for="form_html"><?php esc_html_e( 'Form HTML - We Need name for each input and - No need for FORM tag', 'coco-form' ); ?></label>
            <textarea name="form_html" rows="10"><?php echo esc_textarea( $form->form_html ); ?></textarea>
        </div>

        <!-- Form Top Content -->
        <div class="coco-form-field coco-50-field">
            <label for="form_top"><?php esc_html_e( 'Form Top Content', 'coco-form' ); ?></label>
            <textarea name="form_top" rows="5"><?php echo esc_textarea( $form->form_top ); ?></textarea>
        </div>

        <!-- Form CSS -->
        <div class="coco-form-field coco-50-field">
            <label for="form_css"><?php esc_html_e( 'Form CSS - No need for STYLE tag', 'coco-form' ); ?></label>
            <textarea name="form_css" rows="10"><?php echo esc_textarea( $form->form_css ); ?></textarea>
        </div>

        <!-- Form JavaScript -->
        <div class="coco-form-field coco-50-field">
            <label for="form_js"><?php esc_html_e( 'Form JavaScript - No need for SCRIPT tag', 'coco-form' ); ?></label>
            <textarea name="form_js" rows="10"><?php echo esc_textarea( $form->form_js ); ?></textarea>
        </div>
      <!-- Form email_headers -->
      <div class="coco-form-field coco-50-field">
            <label for="email_headers"><?php esc_html_e( 'Form Headers', 'coco-form' ); ?></label>
            <textarea name="email_headers" rows="5"><?php echo esc_textarea( $form->email_headers ); ?></textarea>
        </div>

         <!-- Form Redirect after submit -->
                <div class="coco-form-field coco-25-field">
            <label for="form_redirect"><?php esc_html_e( 'Url To Redirect After Submit', 'coco-form' ); ?></label>
            <input type="text" name="form_redirect" value="<?php echo esc_attr( $form->form_redirect); ?>" required>
        </div>
      
   <!-- Form Wrapper class -->
   <div class="coco-form-field coco-25-field">
            <label for="form_wrapper_class"><?php esc_html_e( 'Css Class To Wrap Form', 'coco-form' ); ?></label>
            <input type="text" name="form_wrapper_class" value="<?php echo esc_attr( $form->form_wrapper_class); ?>" required>
        </div>
   <!-- Form Css class -->
   <div class="coco-form-field coco-25-field">
            <label for="form_class"><?php esc_html_e( 'Css Class for Form tag', 'coco-form' ); ?></label>
            <input type="text" name="form_class" value="<?php echo esc_attr( $form->form_class); ?>" required>
        </div>

        

        <!-- Additional Settings -->
        <div class="coco-form-field coco-25-field">
            <label for="delay_time"><?php esc_html_e( 'Delay Time (ms)', 'coco-form' ); ?></label>
            <input type="number" name="delay_time" value="<?php echo esc_attr( $form->delay_time ); ?>" min="0">
        </div>

        <div class="coco-form-field coco-25-field">
            <label for="frequency"><?php esc_html_e( 'Frequency (days)', 'coco-form' ); ?></label>
            <select name="frequency">
                <option value="default" <?php selected( $form->frequency, 'default' ); ?>><?php esc_html_e( 'Always Show', 'coco-form' ); ?></option>
                <?php for ( $i = 1; $i <= 30; $i++ ) : ?>
                    <option value="<?php echo esc_attr( $i ); ?>" <?php selected( $form->frequency, $i ); ?>><?php printf( esc_html__( '%d day(s)', 'coco-form' ), $i ); ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="coco-form-field coco-25-field">
            <label for="display_device"><?php esc_html_e( 'Display Device', 'coco-form' ); ?></label>
            <select name="display_device">
                <option value="all" <?php selected( $form->display_device, 'all' ); ?>><?php esc_html_e( 'All Devices', 'coco-form' ); ?></option>
                <option value="desktop" <?php selected( $form->display_device, 'desktop' ); ?>><?php esc_html_e( 'Desktop', 'coco-form' ); ?></option>
                <option value="mobile" <?php selected( $form->display_device, 'mobile' ); ?>><?php esc_html_e( 'Mobile', 'coco-form' ); ?></option>
            </select>
        </div>

        <!-- Form Options -->
        <div class="coco-form-field coco-25-field">
            <label>
                <input type="checkbox" name="is_active" <?php checked( $form->is_active, 1 ); ?>>
                <?php esc_html_e( 'Is Active?', 'coco-form' ); ?>
            </label>
        </div>

        <div class="coco-form-field coco-25-field">
            <label>
                <input type="checkbox" name="is_popup" <?php checked( $form->is_popup, 1 ); ?>>
                <?php esc_html_e( 'Display as Popup?', 'coco-form' ); ?>
            </label>
        </div>

        <!-- Email Templates -->
        <div class="coco-form-field coco-25-field">
            <label for="admin_template_choice"><?php esc_html_e( 'Admin Email Template', 'coco-form' ); ?></label>
            <select name="admin_template_choice">
                <option value="default" <?php selected( $form->admin_template_choice, 'default' ); ?>><?php esc_html_e( 'Default Template', 'coco-form' ); ?></option>
                <option value="template-1" <?php selected( $form->admin_template_choice, 'template-1' ); ?>><?php esc_html_e( 'Template 1', 'coco-form' ); ?></option>
                <option value="template-2" <?php selected( $form->admin_template_choice, 'template-2' ); ?>><?php esc_html_e( 'Template 2', 'coco-form' ); ?></option>
                <option value="template-3" <?php selected( $form->admin_template_choice, 'template-3' ); ?>><?php esc_html_e( 'Template 3', 'coco-form' ); ?></option>
            </select>
        </div>

        <div class="coco-form-field coco-25-field">
            <label for="replay_template_choice"><?php esc_html_e( 'User Reply Email Template', 'coco-form' ); ?></label>
            <select name="replay_template_choice">
                <option value="default" <?php selected( $form->replay_template_choice, 'default' ); ?>><?php esc_html_e( 'Default Template', 'coco-form' ); ?></option>
                <option value="template-1" <?php selected( $form->replay_template_choice, 'template-1' ); ?>><?php esc_html_e( 'Template 1', 'coco-form' ); ?></option>
                <option value="template-2" <?php selected( $form->replay_template_choice, 'template-2' ); ?>><?php esc_html_e( 'Template 2', 'coco-form' ); ?></option>
                <option value="template-3" <?php selected( $form->replay_template_choice, 'template-3' ); ?>><?php esc_html_e( 'Template 3', 'coco-form' ); ?></option>
            </select>
        </div>

        <!-- Submit Button -->
        <div class="coco-form-actions">
            <input type="submit" value="<?php echo $form_id ? esc_attr__( 'Update Form', 'coco-form' ) : esc_attr__( 'Create Form', 'coco-form' ); ?>" class="button button-primary">
        </div>
    </form>
</div>
