<?php
// admin/partials/settings-page.php

defined( 'ABSPATH' ) || exit;

// Check if the user has sufficient permissions
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( __( 'You do not have sufficient permissions to access this page.', 'coco-form' ) );
}
?>

<div class="wrap">
    <h1><?php esc_html_e( 'Coco Form Settings', 'coco-form' ); ?></h1>

    <form method="post" action="options.php">
        <?php
        // Output security fields for the registered setting "coco_form_settings"
        settings_fields( 'coco_form_settings' );

        // Output setting sections and their fields
        do_settings_sections( 'coco_form_settings' );

        // Output save settings button
        submit_button();
        ?>
    </form>

    <h3><a href="https://www.google.com/recaptcha/admin/create" target="_blank">Get reCAPTCHA 3 Keys</a></h3>
    <form method="post" action="options.php">
        <?php
        settings_fields( 'coco_form_recaptcha_settings' );
        do_settings_sections( 'coco_form_recaptcha_settings' );
        submit_button();
        ?>
    </form>
</div>
