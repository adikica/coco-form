<?php
// admin/class-coco-form-admin-settings.php

defined( 'ABSPATH' ) || exit;

class Coco_Form_Admin_Settings {

    /**
     * Initialize the settings.
     */
    public function __construct() {
        add_action( 'admin_init', [ $this, 'register_settings' ] );
    }

    /**
     * Register plugin settings.
     */
    public function register_settings() {
        // General Settings
        register_setting( 'coco_form_settings', 'coco_form_allowed_email_providers' );
        register_setting( 'coco_form_settings', 'coco_form_disallowed_words' );

        add_settings_section(
            'coco_form_general_settings',
            __( 'General Settings', 'coco-form' ),
            null,
            'coco_form_settings'
        );

        add_settings_field(
            'coco_form_allowed_email_providers',
            __( 'Allowed Email Providers', 'coco-form' ),
            [ $this, 'allowed_email_providers_callback' ],
            'coco_form_settings',
            'coco_form_general_settings'
        );

        add_settings_field(
            'coco_form_disallowed_words',
            __( 'Disallowed Words', 'coco-form' ),
            [ $this, 'disallowed_words_callback' ],
            'coco_form_settings',
            'coco_form_general_settings'
        );

        // reCAPTCHA Settings
        register_setting( 'coco_form_recaptcha_settings', 'coco_form_recaptcha_site_key' );
        register_setting( 'coco_form_recaptcha_settings', 'coco_form_recaptcha_secret_key' );

        add_settings_section(
            'coco_form_recaptcha_settings_section',
            __( 'reCAPTCHA Settings', 'coco-form' ),
            null,
            'coco_form_recaptcha_settings'
        );

        add_settings_field(
            'coco_form_recaptcha_site_key',
            __( 'Site Key', 'coco-form' ),
            [ $this, 'recaptcha_site_key_callback' ],
            'coco_form_recaptcha_settings',
            'coco_form_recaptcha_settings_section'
        );

        add_settings_field(
            'coco_form_recaptcha_secret_key',
            __( 'Secret Key', 'coco-form' ),
            [ $this, 'recaptcha_secret_key_callback' ],
            'coco_form_recaptcha_settings',
            'coco_form_recaptcha_settings_section'
        );
    }

    /**
     * Allowed email providers callback.
     */
    public function allowed_email_providers_callback() {
        $value = get_option( 'coco_form_allowed_email_providers', '' );
        echo '<textarea name="coco_form_allowed_email_providers" rows="5" cols="50" class="large-text allowed-disallowed">' . esc_textarea( $value ) . '</textarea>';
        echo '<p class="description">' . __( 'Enter one email provider per line, e.g., gmail.com, yahoo.com.', 'coco-form' ) . '</p>';
    }

    /**
     * Disallowed words callback.
     */
    public function disallowed_words_callback() {
        $value = get_option( 'coco_form_disallowed_words', '' );
        echo '<textarea name="coco_form_disallowed_words" rows="5" cols="50" class="large-text allowed-disallowed">' . esc_textarea( $value ) . '</textarea>';
        echo '<p class="description">' . __( 'Enter one word per line. If any of these words are found in the message, the submission will be blocked.', 'coco-form' ) . '</p>';
    }

    /**
     * reCAPTCHA site key callback.
     */
    public function recaptcha_site_key_callback() {
        $value = get_option( 'coco_form_recaptcha_site_key', '' );
        echo '<input type="text" name="coco_form_recaptcha_site_key" value="' . esc_attr( $value ) . '" class="regular-text">';
    }

    /**
     * reCAPTCHA secret key callback.
     */
    public function recaptcha_secret_key_callback() {
        $value = get_option( 'coco_form_recaptcha_secret_key', '' );
        echo '<input type="text" name="coco_form_recaptcha_secret_key" value="' . esc_attr( $value ) . '" class="regular-text">';
    }
}

new Coco_Form_Admin_Settings();
