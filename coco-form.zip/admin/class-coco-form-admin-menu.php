<?php
// admin/class-coco-form-admin-menu.php

defined( 'ABSPATH' ) || exit;

class Coco_Form_Admin_Menu {

    /**
     * Initialize the admin menu.
     */
    public function __construct() {
        add_action( 'admin_menu', [ $this, 'add_plugin_admin_menu' ] );
    }

    /**
     * Add the plugin admin menu.
     */
    public function add_plugin_admin_menu() {
        add_menu_page(
            __( 'Coco Form', 'coco-form' ),
            __( 'Coco Form', 'coco-form' ),
            'manage_options',
            'coco-form',
            [ $this, 'display_forms_list' ],
            'dashicons-feedback',
            6
        );

        add_submenu_page(
            'coco-form',
            __( 'All Forms', 'coco-form' ),
            __( 'All Forms', 'coco-form' ),
            'manage_options',
            'coco-form',
            [ $this, 'display_forms_list' ]
        );

        add_submenu_page(
            'coco-form',
            __( 'Add New Form', 'coco-form' ),
            __( 'Add New Form', 'coco-form' ),
            'manage_options',
            'coco-form-add',
            [ $this, 'display_form_edit_page' ]
        );

        add_submenu_page(
            'coco-form',
            __( 'Form Entries', 'coco-form' ),
            __( 'Form Entries', 'coco-form' ),
            'manage_options',
            'coco-form-entries',
            [ $this, 'display_form_entries' ]
        );

        add_submenu_page(
            'coco-form',
            __( 'Spam Entries', 'coco-form' ),
            __( 'Spam Entries', 'coco-form' ),
            'manage_options',
            'coco-form-spam',
            [ $this, 'display_spam_entries' ]
        );

        add_submenu_page(
            'coco-form',
            __( 'Settings', 'coco-form' ),
            __( 'Settings', 'coco-form' ),
            'manage_options',
            'coco-form-settings',
            [ $this, 'display_settings_page' ]
        );
    }

    /**
     * Display the forms list page.
     */
    public function display_forms_list() {
        require_once plugin_dir_path( __FILE__ ) . 'partials/form-list-page.php';
    }

    /**
     * Display the form edit page.
     */
    public function display_form_edit_page() {
        require_once plugin_dir_path( __FILE__ ) . 'partials/form-edit-page.php';
    }

    /**
     * Display the form entries page.
     */
    public function display_form_entries() {
        require_once plugin_dir_path( __FILE__ ) . 'partials/form-entries-page.php';
    }

    /**
     * Display the spam entries page.
     */
    public function display_spam_entries() {
        require_once plugin_dir_path( __FILE__ ) . 'partials/spam-entries-page.php';
    }

    /**
     * Display the settings page.
     */
    public function display_settings_page() {
        require_once plugin_dir_path( __FILE__ ) . 'partials/settings-page.php';
    }
}

new Coco_Form_Admin_Menu();
